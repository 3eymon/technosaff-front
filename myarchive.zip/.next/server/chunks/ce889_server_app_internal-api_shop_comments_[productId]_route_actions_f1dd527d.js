module.exports=[567279,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_internal-api_shop_comments_%5BproductId%5D_route_actions_f1dd527d.js.map