module.exports=[836961,a=>{"use strict";var b=a.i(692406);a.s([],536641),a.i(536641),a.s(["003db00ced014bff264fdb656ae6ef9ee08b708d83",()=>b.GetUserDashboard],836961)}];

//# sourceMappingURL=_next-internal_server_app__not-found_page_actions_81b87c68.js.map