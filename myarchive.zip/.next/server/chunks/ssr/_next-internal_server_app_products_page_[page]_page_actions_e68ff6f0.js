module.exports=[607353,a=>{"use strict";var b=a.i(692406);a.s([],487985),a.i(487985),a.s(["003db00ced014bff264fdb656ae6ef9ee08b708d83",()=>b.GetUserDashboard],607353)}];

//# sourceMappingURL=_next-internal_server_app_products_page_%5Bpage%5D_page_actions_e68ff6f0.js.map