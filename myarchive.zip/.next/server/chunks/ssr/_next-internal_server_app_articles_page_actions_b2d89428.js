module.exports=[820538,a=>{"use strict";var b=a.i(692406);a.s([],39381),a.i(39381),a.s(["003db00ced014bff264fdb656ae6ef9ee08b708d83",()=>b.GetUserDashboard],820538)}];

//# sourceMappingURL=_next-internal_server_app_articles_page_actions_b2d89428.js.map