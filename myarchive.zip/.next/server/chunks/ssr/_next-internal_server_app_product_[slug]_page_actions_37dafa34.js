module.exports=[442550,a=>{"use strict";var b=a.i(692406);a.s([],638006),a.i(638006),a.s(["003db00ced014bff264fdb656ae6ef9ee08b708d83",()=>b.GetUserDashboard],442550)}];

//# sourceMappingURL=_next-internal_server_app_product_%5Bslug%5D_page_actions_37dafa34.js.map