module.exports=[878608,a=>{"use strict";var b=a.i(692406);a.s([],977657),a.i(977657),a.s(["003db00ced014bff264fdb656ae6ef9ee08b708d83",()=>b.GetUserDashboard],878608)}];

//# sourceMappingURL=_next-internal_server_app_articles_page_%5Bpage%5D_page_actions_c8fbaf99.js.map