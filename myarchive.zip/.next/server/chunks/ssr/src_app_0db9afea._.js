module.exports=[407524,a=>{a.v("/_next/static/media/icon.ed3bab9c.svg")},839375,a=>{"use strict";let b={src:a.i(407524).default,width:103,height:95};a.s(["default",0,b])}];

//# sourceMappingURL=src_app_0db9afea._.js.map