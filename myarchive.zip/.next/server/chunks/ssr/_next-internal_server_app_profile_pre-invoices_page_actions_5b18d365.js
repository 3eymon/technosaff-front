module.exports=[408414,a=>{"use strict";var b=a.i(692406);a.s([],761331),a.i(761331),a.s(["003db00ced014bff264fdb656ae6ef9ee08b708d83",()=>b.GetUserDashboard],408414)}];

//# sourceMappingURL=_next-internal_server_app_profile_pre-invoices_page_actions_5b18d365.js.map