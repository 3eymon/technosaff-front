module.exports=[172715,a=>{"use strict";var b=a.i(692406);a.s([],307197),a.i(307197),a.s(["003db00ced014bff264fdb656ae6ef9ee08b708d83",()=>b.GetUserDashboard],172715)}];

//# sourceMappingURL=_next-internal_server_app_profile_orders_%5Border_number%5D_page_actions_8af3a3e7.js.map