module.exports=[414742,a=>{"use strict";var b=a.i(692406);a.s([],704230),a.i(704230),a.s(["003db00ced014bff264fdb656ae6ef9ee08b708d83",()=>b.GetUserDashboard],414742)}];

//# sourceMappingURL=_next-internal_server_app_products_offers_page_actions_ff975b3d.js.map