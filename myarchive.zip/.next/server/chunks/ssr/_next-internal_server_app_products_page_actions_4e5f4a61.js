module.exports=[406308,a=>{"use strict";var b=a.i(692406);a.s([],449607),a.i(449607),a.s(["003db00ced014bff264fdb656ae6ef9ee08b708d83",()=>b.GetUserDashboard],406308)}];

//# sourceMappingURL=_next-internal_server_app_products_page_actions_4e5f4a61.js.map