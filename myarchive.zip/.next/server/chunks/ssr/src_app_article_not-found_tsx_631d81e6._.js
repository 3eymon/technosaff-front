module.exports=[300227,a=>{"use strict";var b=a.i(907997),c=a.i(545869);a.s(["default",0,function(){return(0,b.jsx)(c.default,{link:"/articles",linkText:"برگشت به صفحه مقالات"})}])}];

//# sourceMappingURL=src_app_article_not-found_tsx_631d81e6._.js.map