module.exports=[425102,a=>{"use strict";var b=a.i(692406);a.s([],661575),a.i(661575),a.s(["003db00ced014bff264fdb656ae6ef9ee08b708d83",()=>b.GetUserDashboard],425102)}];

//# sourceMappingURL=_next-internal_server_app_profile_order_create_page_actions_95b079ac.js.map