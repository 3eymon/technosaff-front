module.exports=[254779,a=>{"use strict";var b=a.i(692406);a.s([],619434),a.i(619434),a.s(["003db00ced014bff264fdb656ae6ef9ee08b708d83",()=>b.GetUserDashboard],254779)}];

//# sourceMappingURL=_next-internal_server_app_profile_pre-invoices_%5Bid%5D_page_actions_cf2000e4.js.map