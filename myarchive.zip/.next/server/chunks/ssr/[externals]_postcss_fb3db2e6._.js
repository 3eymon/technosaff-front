module.exports=[447082,(a,b,c)=>{b.exports=a.x("postcss-9745a0d11e3197ae",()=>require("postcss-9745a0d11e3197ae"))}];

//# sourceMappingURL=%5Bexternals%5D_postcss_fb3db2e6._.js.map