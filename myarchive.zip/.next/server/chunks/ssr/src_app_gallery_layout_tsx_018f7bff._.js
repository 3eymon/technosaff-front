module.exports=[831495,a=>{"use strict";var b=a.i(907997);function c({children:a,modal:c}){return(0,b.jsxs)("div",{className:"container customSm:max-w-[566px]",children:[a,c]})}a.s(["default",()=>c])}];

//# sourceMappingURL=src_app_gallery_layout_tsx_018f7bff._.js.map