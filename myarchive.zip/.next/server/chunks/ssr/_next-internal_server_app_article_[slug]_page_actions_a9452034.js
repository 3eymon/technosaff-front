module.exports=[714270,a=>{"use strict";var b=a.i(692406);a.s([],175540),a.i(175540),a.s(["003db00ced014bff264fdb656ae6ef9ee08b708d83",()=>b.GetUserDashboard],714270)}];

//# sourceMappingURL=_next-internal_server_app_article_%5Bslug%5D_page_actions_a9452034.js.map