module.exports=[110585,a=>{a.v("/_next/static/media/favicon.f6f3592a.ico")},68611,a=>{"use strict";let b={src:a.i(110585).default,width:48,height:48};a.s(["default",0,b])}];

//# sourceMappingURL=src_app_5b2047f8._.js.map