module.exports=[592915,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_internal-api_shop_cart_clear_route_actions_5f0163e5.js.map