module.exports=[989430,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_internal-api_shop_order_normal_route_actions_23bc407a.js.map