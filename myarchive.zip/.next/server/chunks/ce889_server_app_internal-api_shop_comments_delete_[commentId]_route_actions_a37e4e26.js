module.exports=[832947,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_internal-api_shop_comments_delete_%5BcommentId%5D_route_actions_a37e4e26.js.map