var R=require("../../chunks/[turbopack]_runtime.js")("server/app/manifest.json/route.js")
R.c("server/chunks/[root-of-the-server]__1e794d39._.js")
R.c("server/chunks/[root-of-the-server]__24f8fcd9._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_manifest_json_route_actions_c5412385.js")
R.m(422945)
module.exports=R.m(422945).exports
