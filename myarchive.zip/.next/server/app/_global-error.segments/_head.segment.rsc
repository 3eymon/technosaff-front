1:"$Sreact.fragment"
2:I[897367,["/_next/static/chunks/d96012bcfc98706a.js","/_next/static/chunks/9e80aaa07d4729bb.js"],"ViewportBoundary"]
3:I[897367,["/_next/static/chunks/d96012bcfc98706a.js","/_next/static/chunks/9e80aaa07d4729bb.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[27201,["/_next/static/chunks/d96012bcfc98706a.js","/_next/static/chunks/9e80aaa07d4729bb.js"],"IconMark"]
0:{"buildId":"Dfj1QX1HgWde4VfC-ysuJ","rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","link","0",{"rel":"manifest","href":"/manifest.json"}],["$","link","1",{"rel":"icon","href":"/favicon.ico?favicon.f6f3592a.ico","sizes":"48x48","type":"image/x-icon"}],["$","$L5","2",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"loading":null,"isPartial":false}
