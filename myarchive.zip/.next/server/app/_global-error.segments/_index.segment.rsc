1:"$Sreact.fragment"
2:I[339756,["/_next/static/chunks/d96012bcfc98706a.js","/_next/static/chunks/9e80aaa07d4729bb.js"],"default"]
3:I[837457,["/_next/static/chunks/d96012bcfc98706a.js","/_next/static/chunks/9e80aaa07d4729bb.js"],"default"]
0:{"buildId":"Dfj1QX1HgWde4VfC-ysuJ","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
