var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/internal-api/shop/discount/check/route.js")
R.c("server/chunks/[root-of-the-server]__d64973f0._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/[root-of-the-server]__24f8fcd9._.js")
R.c("server/chunks/_d96f9274._.js")
R.c("server/chunks/[root-of-the-server]__0bb0c6d3._.js")
R.c("server/chunks/ce889_server_app_internal-api_shop_discount_check_route_actions_b5f73978.js")
R.m(604251)
module.exports=R.m(604251).exports
