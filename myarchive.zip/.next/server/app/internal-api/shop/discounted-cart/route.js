var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/internal-api/shop/discounted-cart/route.js")
R.c("server/chunks/[root-of-the-server]__5b215735._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/[root-of-the-server]__24f8fcd9._.js")
R.c("server/chunks/_d96f9274._.js")
R.c("server/chunks/[root-of-the-server]__0bb0c6d3._.js")
R.c("server/chunks/ce889_server_app_internal-api_shop_discounted-cart_route_actions_81371e74.js")
R.m(944102)
module.exports=R.m(944102).exports
