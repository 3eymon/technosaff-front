var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/internal-api/shop/order/discounted/route.js")
R.c("server/chunks/[root-of-the-server]__7d54fbe7._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/[root-of-the-server]__24f8fcd9._.js")
R.c("server/chunks/_d96f9274._.js")
R.c("server/chunks/[root-of-the-server]__0bb0c6d3._.js")
R.c("server/chunks/ce889_server_app_internal-api_shop_order_discounted_route_actions_8e63f711.js")
R.m(633470)
module.exports=R.m(633470).exports
