var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/internal-api/shop/order/normal/route.js")
R.c("server/chunks/[root-of-the-server]__91d12e1a._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/[root-of-the-server]__24f8fcd9._.js")
R.c("server/chunks/_d96f9274._.js")
R.c("server/chunks/[root-of-the-server]__0bb0c6d3._.js")
R.c("server/chunks/_next-internal_server_app_internal-api_shop_order_normal_route_actions_23bc407a.js")
R.m(610909)
module.exports=R.m(610909).exports
