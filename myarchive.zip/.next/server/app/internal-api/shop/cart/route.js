var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/internal-api/shop/cart/route.js")
R.c("server/chunks/[root-of-the-server]__ca5eb6ca._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/[root-of-the-server]__24f8fcd9._.js")
R.c("server/chunks/_d96f9274._.js")
R.c("server/chunks/[root-of-the-server]__0bb0c6d3._.js")
R.c("server/chunks/_next-internal_server_app_internal-api_shop_cart_route_actions_75655690.js")
R.m(178644)
module.exports=R.m(178644).exports
