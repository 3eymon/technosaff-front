var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/internal-api/auth/refresh/route.js")
R.c("server/chunks/[root-of-the-server]__59a83804._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/[root-of-the-server]__24f8fcd9._.js")
R.c("server/chunks/_d96f9274._.js")
R.c("server/chunks/[root-of-the-server]__0bb0c6d3._.js")
R.c("server/chunks/_next-internal_server_app_internal-api_auth_refresh_route_actions_24e13ad1.js")
R.m(661188)
module.exports=R.m(661188).exports
