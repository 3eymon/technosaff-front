var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/internal-api/auth/verify-otp/route.js")
R.c("server/chunks/[root-of-the-server]__fb68145e._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/[root-of-the-server]__24f8fcd9._.js")
R.c("server/chunks/_d96f9274._.js")
R.c("server/chunks/[root-of-the-server]__0bb0c6d3._.js")
R.c("server/chunks/_next-internal_server_app_internal-api_auth_verify-otp_route_actions_0a017180.js")
R.m(536684)
module.exports=R.m(536684).exports
