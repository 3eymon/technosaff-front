var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/internal-api/auth/logout/route.js")
R.c("server/chunks/[root-of-the-server]__2c7bb336._.js")
R.c("server/chunks/[root-of-the-server]__24f8fcd9._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_internal-api_auth_logout_route_actions_17618135.js")
R.m(268799)
module.exports=R.m(268799).exports
