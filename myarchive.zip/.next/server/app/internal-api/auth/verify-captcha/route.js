var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/internal-api/auth/verify-captcha/route.js")
R.c("server/chunks/[root-of-the-server]__2211d1dd._.js")
R.c("server/chunks/[root-of-the-server]__24f8fcd9._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/ce889_server_app_internal-api_auth_verify-captcha_route_actions_4cff593e.js")
R.m(165753)
module.exports=R.m(165753).exports
