var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/internal-api/marketing/store/[store_name_english]/order/create/route.js")
R.c("server/chunks/[root-of-the-server]__1243fcbb._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/[root-of-the-server]__24f8fcd9._.js")
R.c("server/chunks/_d96f9274._.js")
R.c("server/chunks/[root-of-the-server]__0bb0c6d3._.js")
R.c("server/chunks/c1a4f_marketing_store_[store_name_english]_order_create_route_actions_9a05a0e3.js")
R.m(178152)
module.exports=R.m(178152).exports
