globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/9a821ddf2b9afd3b.js",
    "static/chunks/2119be3a1d430a7d.js",
    "static/chunks/393752ef7748ec37.js",
    "static/chunks/b2c3f0a46ede7d91.js",
    "static/chunks/83db174c815c2c98.js",
    "static/chunks/turbopack-c4ff258efdf6a610.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];